const express = require('express');
const db = require('./database');
const router = express.Router();

// STEPS routes



module.exports = router;