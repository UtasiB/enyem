const express = require('express');
const http = require('http');
const socketio = require('socket.io');
const ejs = require('ejs');

const app = express();
const server = http.createServer(app);
const io = socketio(server);

const port = 3000;

app.use('/assets', express.static('assets'));


app.get('/', (req, res)=>{
    res.render('index.ejs');
});

app.post('/chat', (req, res)=>{
   // let { name, room } = req.body;
    res.render('chat.ejs');
});

io.on('connection', (socket)=>{

});


server.listen(port, ()=>{
    console.log(`Server listening on http://localhost:${port}`);
});