/**
 *  GENERIC NodeJS REST API for Frontend Applications
*   -------------------------------------------------------
 *  Bajai SZC Türr István Technikum, 13.a szoftverfejlesztő
 *  2024. november
 */

// REQUIREMENTS
require('dotenv').config();
const express = require('express');
var mysql = require('mysql');
const cors = require('cors');
const app = express();
const port = process.env.PORT;

// MIDDLEWARE FUNCION
app.use(express.urlencoded({extended: true}));
app.use(cors());
app.use(express.json());

// DATABASE CONNECTION
var pool  = mysql.createPool({
    connectionLimit : 10,
    host            : process.env.DBHOST,
    user            : process.env.DBUSER,
    password        : process.env.DBPASS,
    database        : process.env.DBNAME
});

// APP ROUTES

// GET all records from :table
app.get('/:table', (req, res)=>{

    let table = req.params.table;

    pool.query(`SELECT * FROM ${table}`,  (err, results)=>{
        sendResults(res, err, results);
    });
});

// GET records from :table by :field
app.get('/:table/:field/:op/:value', (req, res)=>{

    let table = req.params.table;
    let field = req.params.field;
    let value = req.params.value;
    let op = getOP(req.params.op);

    if (req.params.op == 'lk'){
        value = `%${value}%`;
    }

    pool.query(`SELECT * FROM ${table} WHERE ${field}${op}'${value}'`,  (err, results)=>{
       sendResults(res, err, results);
    });
});

// INSERT record to :table
app.post('/:table', (req, res)=>{

});

// UPDATE records in :table by :field
app.patch('/:table/:field/:op/:value', (req, res)=>{

});

// DELETE record(s) from :table by :field
app.delete('/:table/:field/:op/:value', (req, res)=>{

});

// DELETE all records from :table
app.delete('/:table', (req, res)=>{

});

// FUNCTIONS
function getOP(op){
    switch(op){
      case 'eq' : { op = '='; break }
      case 'lt' : { op = '<'; break }
      case 'gt' : { op = '>'; break }
      case 'lte': { op = '<='; break }
      case 'gte': { op = '>='; break }
      case 'not': { op = '!='; break }
      case 'lk' : { op = ' like '; break }
    }
    return op;
}

function sendResults(res, err, results){
    if (err){
        res.status(500).send(err);
        return
    }
    res.status(200).send(results);
}

// LISTENING
app.listen(port, () => {
    console.log(`Server listening on http://localhost:${port}`);
});

