require('dotenv').config();
const express = require('express');
var ejs = require('ejs');
const app = express();
const port = process.env.PORT;

app.use('/assets', express.static('assets'));

var mysql      = require('mysql');
var connection = mysql.createConnection({
  host     : process.env.DBHOST,
  user     : process.env.DBUSER,
  password : process.env.DBPASS,
  database : process.env.DBNAME
});
 
connection.connect((err)=>{
    if (err){
        console.log(err);
        return;
    }
    console.log(`Connected to MySQL database.`)
});

app.get('/', function (req, res) {
  connection.query(`SELECT * FROM forgalom INNER JOIN kategoria ON kategoria.id = forgalom.kategoriaId`, (err, results)=>{
    if (err){
      ejs.renderFile('views/error.ejs', (err, html)=>{
        res.send(html);
      })
      return
    }
    ejs.renderFile('views/index.ejs', {results}, (err, html) => {
      if (err){
        console.log(err)
      }
      res.send(html);
    });
  });

  
})

app.listen(port, ()=>{
    console.log(`Server listening on port ${port}...`);
});