require('dotenv').config();
const express = require('express');

const coreRoutes = require('./modules/core');
const userRoutes = require('./modules/users');
const stepRoutes = require('./modules/steps');

const app = express();
const port = process.env.PORT;

app.use(express.json());
app.use(express.urlencoded({extended: true}));
app.use('/assets', express.static('assets'));

// routes
app.use('/', coreRoutes);
app.use('/users', userRoutes); 
app.use('/steps', stepRoutes);


app.listen(port, ()=>{
    console.log(`Server listening on port ${port}...`);
});