const express = require('express');
const db = require('./database');
const uuid = require('uuid');
const router = express.Router();
const passwdRegExp = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d]{8,}$/;

// USER routes
router.post('/reg', (req, res) => {
    console.log(req.body);
    let { name, email, passwd, confirm } = req.body;

    if (!name || !email || !passwd || !confirm) {
        //TODO: hibaüzenet kell!!!
        res.redirect('/reg');
        return
    }

    if (passwd != confirm){
        //TODO: hibaüzenet kell!!!
        res.redirect('/reg');
        return
    }

    if (!passwd.match(passwdRegExp)){
        //TODO: hibaüzenet kell!!!
        res.redirect('/reg'); 
        return
    }

    db.pool(`SELECT * FROM users WHERE email=?`, [email], (err, results)=>{
        if (err){
            //TODO: hibaüzentet kell!!!
            res.redirect('/');
            return
        }

        db.pool(`INSERT INTO users (ID, name, email, password, role) VALUES(?, ?, ?, SHA1(?), 'user')`, 
            [uuid.v4(), name, email, passwd], (err, results)=>{
            if (err){
                //TODO: hibaüzentet kell!!!
                res.redirect('/');
                return
            }
            //TODO: sikeres reg üzenet!!! majd login
            return
        })
    });

});

module.exports = router;