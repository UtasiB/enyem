const express = require('express');
const axios = require('axios');
const app = express();

app.use(express.json());

const GOOGLEAPIKEY = 'your google api key';

/**
 * GET location by local name from GOOGLE MAPS
 */
app.post('/find', async (req, res)=>{
    const { location } = req.body;

    if (!location){
        return res.status(400).json({error: 'A hely megadása kötelező!'});
    }

    try{

        const response = await axios.get('https://maps.googleapis.com/maps/api/place/findplacefromtext/json', {
            params: {
                input: location,
                inputtype: 'textquery',
                fields: 'formatted_address,name,geometry,place_id',
                key: GOOGLEAPIKEY
            }
        });

        const data = response.data;

        if (data.status == 'OK'){
            const place = data.candidates[0];
            
            res.status(200).json({
                name: place.name,
                address: place.formatted_address,
                location: place.geometry.location,
                placa_id: place.place_id
            })
        
        }else{
            res.status(400).json({ error: 'Nem található ilyen hely!'});
        }
        

    }catch(error){
        console.log(error);
        res.status(500).json({error:'Szerver hiba történt!'});
    }
});


/**
 * GET distance from baja bácska tér 1, to destination by GOOGLE MAPS
 */
app.post('/distance', async (req, res)=>{
    const { destination } = req.body;
    const origin = 'Baja, Bácska tér 1.';

    if (!destination){
        return res.status(400).json({error: 'A célcím megadása kötelező!'});
    }

    try{

        const response = await axios.get('https://maps.googleapis.com/maps/api/distancematrix/json', {
            params: {
                origins: origin,
                destinations: destination,
                key: GOOGLEAPIKEY,
                units: 'mertic' 
            }
        });

        const data = response.data;

        
        if (data.status == 'OK'){
            const result = data.rows[0].elements[0];
            
            res.status(200).json({
               distance: result.distance.text,
               duration: result.duration.text
            })
        
        }else{
            res.status(400).json({ error: 'Nem található ilyen cím!'});
        }
        
    }catch(error){
        console.log(error);
        res.status(500).json({error:'Szerver hiba történt!'});
    }
});

app.listen(3000, ()=>{
    console.log('http://localhost:3000');
})