let users = [];
let rooms = [ 'prog', 'films', 'music', 'games'];

function userJoin(){}

function userLeave(){}

function getRoomUsers(){}

module.exports = {
    users,
    rooms,
    userJoin,
    userLeave,
    getRoomUsers
}