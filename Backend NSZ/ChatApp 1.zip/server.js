const express = require('express');
const http = require('http');
const socketio = require('socket.io');
const ejs = require('ejs');

const app = express();
const server = http.createServer(app);
const io = socketio(server);

const port = 3000;

const { users, rooms, userJoin, userLeave, getRoomUsers } = require('./utils');

app.use('/assets', express.static('assets'));


app.get('/', (req, res)=>{
    res.render('index.ejs');
});

app.get('/chat/:room/:user', (req, res)=>{
   // let { name, room } = req.body;
    res.render('chat.ejs');
});

io.on('connection', (socket)=>{
    console.log(socket.id)

    socket.on('getRoomList', ()=>{
        io.emit('updateRoomList', rooms)
    });
});


server.listen(port, ()=>{
    console.log(`Server listening on http://localhost:${port}`);
});