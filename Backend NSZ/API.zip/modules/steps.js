
const uuid = require('uuid');
const express = require('express');
const router = express.Router();
const db = require('./database');
const { logincheck } =  require('./middlewares');
var moment = require('moment');
 
// összes felhasználó lépésadatainak lekérdezése (CSAK ADMIN)
router.get('/', logincheck, (req, res) => {
  
    db.Query(`SELECT * FROM stepdatas`, (err, results) => {
      if (err){
        res.status(500).send('Hiba történt az adatbázis lekérés közben!');
        return;
      }
  
      res.status(200).send(results);
      return;
  
    });
  
  });
  
// felhasználó lépésadatainak lekérdezése
router.get('/:userID', logincheck, (req, res) => {
if (!req.params.userID) {
    res.status(203).send('Hiányzó azonosító!');
    return;
}

db.Query(`SELECT * FROM stepdatas WHERE userID='${req.params.userID}'`, (err, results) => {
    if (err){
    res.status(500).send('Hiba történt az adatbázis lekérés közben!');
    return;
    }

    res.status(200).send(results);
    return;

});

});

// felhasználó lépésadatainak felvitele
router.post('/:userID', logincheck, (req, res) => {

if (!req.params.userID) {
    res.status(203).send('Hiányzó azonosító!');
    return;
}

if (!req.body.date || !req.body.stepcount) {
    res.status(203).send('Hiányzó adatok!');
    return;
}

let today = moment().format('YYYY-MM-DD');
let date = moment(req.body.date).format('YYYY-MM-DD');

// string-ként összehasonlítjuk a két dátumot
if (date.localeCompare(today) > 0){
    res.status(203).send('A dátum nem lehet jövőbeli!');
    return;
}

db.Query(`SELECT ID FROM stepdatas WHERE userID='${req.params.userID}' AND date='${date}'`, (err ,results) => {
    if (err){
    res.status(500).send('Hiba történt az adatbázis művelet közben!');
    return;
    }

    if (results.length != 0){
    // update
    db.Query(`UPDATE stepdatas SET count=count+${req.body.stepcount} WHERE ID='${results[0].ID}'`, (err) => {
        if (err){
        res.status(500).send('Hiba történt az adatbázis művelet közben!');
        return;
        }
    
        res.status(200).send('A lépésadat hozzáadva a meglévőhöz!');
        return;
    });
    }

    // insert
    if (results.length == 0){
    db.Query(`INSERT INTO stepdatas VALUES('${uuid.v4()}', '${req.params.userID}', '${date}', ${req.body.stepcount})`, (err) => {
    if (err){
        res.status(500).send('Hiba történt az adatbázis művelet közben!');
        return;
    }

    res.status(200).send('A lépésadat felvéve!');
    return;
    });
    }
});

});

// felhasználó lépésadatainak módosítása
router.patch('/:userID', logincheck, (req, res) => {
if (!req.params.userID) {
    res.status(203).send('Hiányzó azonosító!');
    return;
}

if (!req.body.date || !req.body.stepcount) {
    res.status(203).send('Hiányzó adatok!');
    return;
}

let date = moment(req.body.date).format('YYYY-MM-DD');

db.Query(`UPDATE stepdatas SET count=${req.body.stepcount} WHERE userID='${req.params.userID}' AND date='${date}'`, (err, results) => {
    if (err){
    res.status(500).send('Hiba történt az adatbázis művelet közben!');
    return;
    }

    if (results.affectedRows == 0){
    res.status(203).send('Nincs ilyen adat!');
    return;
    }

    res.status(200).send('A lépésadat módosítva!');
    return;

});

});

// felhasználó összes lépésadatainak törlése
router.delete('/:userID', logincheck, (req, res) => {
if (!req.params.userID) {
    res.status(203).send('Hiányzó azonosító!');
    return;
}

// ha nincs dátum megadva, akkor a felhasználó összes lépésadatát töröljük

db.Query(`DELETE FROM stepdatas WHERE userID='${req.params.userID}'`, (err, results) => {
    if (err){
    res.status(500).send('Hiba történt az adatbázis művelet közben!');
    return;
    }

    if (results.affectedRows == 0){
    res.status(203).send('Nincs ilyen adat!');
    return;
    }

    res.status(200).send(`Az összes lépésadat törölve! (${results.affectedRows} nap)`);
    return;

});   

});

// felhasználó lépésadatainak törlése
router.delete('/:userID/:date', logincheck, (req, res)=>{
    
    if (!req.params.userID || !req.params.date) {
    res.status(203).send('Hiányzó paraméter!');
    return;
    }
    
    // ha van dátum, akkor csak azt töröljük
    
    let date = moment(req.params.date).format('YYYY-MM-DD');
    
    db.Query(`DELETE FROM stepdatas WHERE userID='${req.params.userID}' AND date='${date}'`, (err, results) => {
        if (err){
        res.status(500).send('Hiba történt az adatbázis művelet közben!');
        return;
        }

        if (results.affectedRows == 0){
        res.status(203).send('Nincs ilyen adat!');
        return;
        }

        res.status(200).send(`Az lépésadat törölve!`);
        return;

    });   
    
});

module.exports = router;