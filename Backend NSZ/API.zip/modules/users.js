
const uuid = require('uuid');
const express = require('express');
const router = express.Router();
var CryptoJS = require("crypto-js");
const db = require('./database');
const { logincheck, admincheck } =  require('./middlewares');
const passwdRegExp = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d]{8,}$/;

// user regisztráció 
router.post('/reg', (req, res) => {

    // kötelező adatok ellenőrzése
    if (!req.body.name || !req.body.email || !req.body.passwd || !req.body.confirm ){
       res.status(203).send('Nem adtál meg minden kötelező adatot!');
       return;
    }
  
    // jelszavak ellenőrzése
    if (req.body.passwd != req.body.confirm){
      res.status(203).send('A megadott jelszavak nem egyeznek!');
      return;
    }
    
    // jelszó min kritériumoknak megfelelés
    if (!req.body.passwd.match(passwdRegExp)){
      res.status(203).send('A jelszó nem elég biztonságos!');
      return;
    }
  
    // email cím ellenőrzés
    db.Query(`SELECT * FROM users WHERE email='${req.body.email}'`, (err, results) => {
       
      if (err){
        res.status(500).send('Hiba történt az adatbázis elérése közben!');
        return;
       }
      
      // ha van már ilyen email cím
      if (results.length != 0){
        res.status(203).send('Ez az e-mail cím már regisztrálva van!');
        return;
       }
      
      // új felhasználó felvétele
      db.Query(`INSERT INTO users VALUES('${uuid.v4()}', '${req.body.name}', '${req.body.email}', SHA1('${req.body.passwd}'), 'user')`, (err, results)=>{
        if (err){
          res.status(500).send('Hiba történt az adatbázis művelet közben!');
          return;
         }
         res.status(202).send('Sikeres regisztráció!');
         return;
      });
      return;
    });
   
  });
  
// user belépés
router.post('/login', (req, res) => {

//console.log(req.body);
if (!req.body.email || !req.body.passwd) {
    res.status(203).send('Hiányzó adatok!');
    return;
}

db.Query(`SELECT ID, name, email, role FROM users WHERE email ='${req.body.email}' AND passwd='${CryptoJS.SHA1(req.body.passwd)}'`, (err, results) =>{
    if (err){
    res.status(500).send('Hiba történt az adatbázis lekérés közben!');
    return;
    }
    if (results.length == 0){
    res.status(203).send('Hibás belépési adatok!');
    return;
    }
    res.status(202).send(results);
    return;
});

});

// bejelentkezett felhasználó adatainak lekérése
router.get('/me/:id', logincheck, (req, res) => {
//TODO: id-t megoldani backenden majd, hogy ne kelljen itt átadni
if (!req.params.id) {
    res.status(203).send('Hiányzó azonosító!');
    return;
}

db.Query(`SELECT name, email, role FROM users WHERE ID='${req.params.id}'`, (err, results) =>{ 
    if (err){
    res.status(500).send('Hiba történt az adatbázis lekérés közben!');
    return;
    }

    if (results.length == 0){
    res.status(203).send('Hibás azonosító!');
    return;
    }

    res.status(202).send(results);
    return;

});
});

// felhasználó módosítása
router.patch('/:id', logincheck, (req, res) => {

if (!req.params.id) {
    res.status(203).send('Hiányzó azonosító!');
    return;
}

if (!req.body.name || !req.body.email || !req.body.role) {
    res.status(203).send('Hiányzó adatok!');
    return;
}

//TODO: ne módosíthassa már meglévő email címre az email címét

db.Query(`UPDATE users SET name='${req.body.name}', email='${req.body.email}', role='${req.body.role}' WHERE ID='${req.params.id}'`, (err, results) => {
    if (err){
    res.status(500).send('Hiba történt az adatbázis lekérés közben!');
    return;
    }

    if (results.affectedRows == 0){
    res.status(203).send('Hibás azonosító!');
    return;
    }

    res.status(200).send('Felhasználó adatok módosítva!');
    return;
});
});

// jelszó módosítás
router.patch('/passmod/:id', logincheck, (req, res) => {

if (!req.params.id) {
    res.status(203).send('Hiányzó azonosító!');
    return;
}

if (!req.body.oldpass || !req.body.newpass || !req.body.confirm) {
    res.status(203).send('Hiányzó adatok!');
    return;
}

    // jelszavak ellenőrzése
    if (req.body.newpass != req.body.confirm){
    res.status(203).send('A megadott jelszavak nem egyeznek!');
    return;
}

// jelszó min kritériumoknak megfelelés
if (!req.body.newpass.match(passwdRegExp)){
    res.status(203).send('A jelszó nem elég biztonságos!');
    return;
}

// megnézzük, hogy jó-e a megadott jelenlegi jelszó
db.Query(`SELECT passwd FROM users WHERE ID='${req.params.id}'`, (err, results) => {
    if (err){
    res.status(500).send('Hiba történt az adatbázis lekérés közben!');
    return;
    }

    if (results.length == 0){
    res.status(203).send('Hibás azonosító!');
    return;
    }

    if (results[0].passwd != CryptoJS.SHA1(req.body.oldpass)){
    res.status(203).send('A jelenlegi jelszó nem megfelelő!');
    return;
    }

    db.Query(`UPDATE users SET passwd=SHA1('${req.body.newpass}') WHERE ID='${req.params.id}'`, (err, results) => {
    if (err){
        res.status(500).send('Hiba történt az adatbázis lekérés közben!');
        return;
    }

    if (results.affectedRows == 0){
        res.status(203).send('Hibás azonosító!');
        return;
    }

    res.status(200).send('A jelszó módosítva!');
    return;
    });

});

});

// felhasználók listája (CSAK ADMIN)
router.get('/', admincheck, (req, res) => {

    //TODO: csak admin joggal lehet - később

    db.Query(`SELECT ID, name, email, role FROM users`, (err, results) => {
        if (err){
        res.status(500).send('Hiba történt az adatbázis lekérés közben!');
        return;
        }
        res.status(200).send(results);
        return;
    });
});

// felhasználó adatainak lekérése id alapján (CSAK ADMIN)
router.get('/:id', logincheck, (req, res) => {

if (!req.params.id) {
    res.status(203).send('Hiányzó azonosító!');
    return;
    }

    db.Query(`SELECT name, email, role FROM users WHERE ID='${req.params.id}'`, (err, results) =>{ 
    if (err){
        res.status(500).send('Hiba történt az adatbázis lekérés közben!');
        return;
    }

    if (results.length == 0){
        res.status(203).send('Hibás azonosító!');
        return;
    }

    res.status(202).send(results);
    return;

    });
});

// felhasználó törlése id alapján (CSAK ADMIN)
router.delete('/:id', logincheck, (req, res) => {

if (!req.params.id) {
    res.status(203).send('Hiányzó azonosító!');
    return;
}

db.Query(`DELETE FROM users WHERE ID='${req.params.id}'`, (err, results) => {
    
    if (err){
    res.status(500).send('Hiba történt az adatbázis lekérés közben!');
    return;
    }
    
    if (results.affectedRows == 0){
    res.status(203).send('Hibás azonosító!');
    return;
    }

    res.status(200).send('Felhasználó törölve!');
    return;

});
});
  
module.exports = router;