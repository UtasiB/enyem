var clc = require("cli-color");
const moment = require('moment');
const fs = require('fs');

var err = clc.red.bold;
var warn = clc.yellow;
var not = clc.blackBright;
var inf = clc.cyanBright;

var debugmode = Boolean(process.env.DEBUG);
var logtofile = Boolean(process.env.LOGTOFILE);

function writeLogFile(message){
    fs.appendFileSync('api.log', message + '\n', (err) => {
        if (err){
            error('Error writng to a log file: ', err);
        }
    });
}

function error(message){
    const timestamp = moment(new Date()).format('YYYY.MM.DD H:mm:ss');
    const ts = `[${timestamp}]: `;
    if (debugmode) console.log(ts + err(message));
    if (logtofile) writeLogFile(ts + message);
}

function warning(message){
    const timestamp = moment(new Date()).format('YYYY.MM.DD H:mm:ss');
    const ts = `[${timestamp}]: `;
    if (debugmode) console.log(ts + warn(message));
    if (logtofile) writeLogFile(ts + message);
}

function info(message){
    const timestamp = moment(new Date()).format('YYYY.MM.DD H:mm:ss');
    const ts = `[${timestamp}]: `;
    if (debugmode) console.log(ts + inf(message));
    if (logtofile) writeLogFile(ts + message);
}

function notice(message){
    const timestamp = moment(new Date()).format('YYYY.MM.DD H:mm:ss');
    const ts = `[${timestamp}]: `;
    if (debugmode) console.log(ts + not(message));
    if (logtofile) writeLogFile(ts + message);
}

module.exports = { error, warning, info, notice }