require('dotenv').config();
var cors = require('cors');
const express = require('express');
const app = express();
const port = process.env.PORT;
const fs = require('fs');
const userRoutes = require('./modules/users');
const stepRoutes = require('./modules/steps');
const logger = require('./modules/logger');

// middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({extended: true}));

// routes
app.use('/users', userRoutes); 
app.use('/steps', stepRoutes);

// get API version
app.get('/', (req, res) => {
  res.send(`API version : ${process.env.VERSION}`);
});

// clear log file
if (fs.existsSync('api.log')){
  fs.unlinkSync('api.log');
  logger.notice('Existing log file deleted on server start.');
}

app.listen(port, () => {
  logger.info(`Server listening on port ${port}...`);
});

/*
  stepcounter - users, stepdatas
---------------------------------------------
  felhasználó kezelés:
  -------------------------
  POST /reg - user regisztráció  - nincs megkötés
  POST /login - user belépés - nincs megkötés
  GET /me - bejelentkezett felhasználó adatai - logincheck
  GET /users - felhasználók listája - ok (CSAK admin!) - logincheck, admincheck
  GET /users/:id - loginckeck, admincheck
  PATCH /users/:id - logincheck
  PATCH /passmod/:id - logincheck
  DELETE /users/:id - adott id-jű felhasználó tölése (CSAK admin!) - logincheck, admincheck

  lépésadatok keelése:
  --------------------------
  GET /steps - minden felhasználó lépésadatának lekérdezése - logincheck, adminckeck
  GET /steps/:userID - felhasználó lépésadatainak lekérdezése - logincheck
  POST /steps/:userID - felhasználó lépésadat felvitele - logincheck  
  PATCH /steps/:userID - felhasználó lépésadat módosítása - ologincheckk 
  DELETE /steps/:userID - felhasználó lépésadat törlése - logincheck
  DELETE /steps/:userID/:date - felhasználó napi lépésének törlése - logincheck

*/

//stepcount insertnél megnézni, hogy arra a napra van-e már lépés és akkor update insert helyett (adja hozzá a már meglévőhöz) - ok

/**
 *  API v2.0 updates
 * ------------------------------------
 * 1. router használata (express router)
 * pl. user, steps module
 *   POST http://localhost:3000/users/reg
 *   GET http://localhost:3000/users/login
 *   GET http://localhost:3000/users/me
 *   PATCH http://localhost:3000/users/passmod/:id
 * 
 *   GET http://localhost:3000/steps/:userID
 *   DELETE http://localhost:3000/steps/:userID/:date

 */