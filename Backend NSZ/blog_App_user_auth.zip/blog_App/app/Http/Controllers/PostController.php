<?php

namespace App\Http\Controllers;

use App\Models\Post;
use Illuminate\Http\Request;

class PostController extends Controller
{

    /**
     * Show the form for creating a new resource.
     */
    public function create(Request $request)
    {
        $data = $request->validate([
            'title' => 'required',
            'body' => 'required'
        ]);
        $data['user_id'] = auth()->id();
        Post::create($data);
        return redirect('/');
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Post $post)
    {
        if (auth()->user()->id != $post['user_id']){
            return redirect('/');
        }
        return view('postForm', [ 'post' => $post]);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Post $post)
    {
        if (auth()->user()->id != $post['user_id']){
            return redirect('/');
        }
        $data = $request->validate([
            'title' => 'required',
            'body' => 'required'
        ]);

        $post->update($data);
        return redirect('/');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Post $post)
    {
        if (auth()->user()->id === $post['user_id']){
            $post->delete();
        }
        return redirect('/');
    }

}
