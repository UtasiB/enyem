<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Laravel Blog App</title>
    <link rel="stylesheet" href="/app.css">
</head>
<body>
    <div class="container">
        <header>
            <h1>Laravel Blog App</h1>
            <h3>Bajai SZC Türr István Technikum - 5/13.SZOFT</h3>
            <h6>2024.</h6>
        </header>
        <main>
            @if (!isset($post))
                <h3>Create a new post</h3>
                <form action="/create-post" method="post">
                    @csrf
                    <input type="text" name="title" placeholder="post title"><br>
                    <textarea name="body" placeholder="post body..."></textarea><br>
                    <button>Save post</button>
                </form>
            @else
                <h3>Edit post</h3>
                <form action="/edit-post/{{$post->id}}" method="post">
                    @csrf
                    @method('PUT')
                    <input type="text" name="title" placeholder="post title" value="{{$post->title}}"><br>
                    <textarea name="body" placeholder="post body...">{{$post->body}}</textarea><br>
                    <button>Update post</button>
                </form>
            @endif
            <a href="/">Back to the posts list...</a>
        </main>

    </div>
</body>
</html>
