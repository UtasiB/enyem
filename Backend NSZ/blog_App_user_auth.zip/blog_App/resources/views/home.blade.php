<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Laravel Blog App</title>
    <link rel="stylesheet" href="/app.css">
</head>
<body>
    <div class="container">
        <header>
            <h1>Laravel Blog App</h1>
            <h3>Bajai SZC Türr István Technikum - 5/13.SZOFT</h3>
            <h6>2024.</h6>
        </header>
        <main>

            @auth
                <h2>Logged in</h2>
                <form action="/logout" method="post">
                    @csrf
                    <a href="/newpost">Create a new post</a>
                    <button>Logout</button>
                </form>

                <h2>All posts</h2>
                <hr>
                @foreach ($posts as $post)
                   <h3>{{ $post->title }}</h3>
                   <p>{{$post->body}}</p>
                   <a href="/edit-post/{{$post->id}}">Edit post</a>
                   <form action="/delete-post/{{$post->id}}" method="post">
                        @csrf
                        @method('DELETE')
                        <button>Delete</button>
                   </form>
                   <hr>
                @endforeach

            @else
                <h2>Login</h2>
                <form action="/login" method="post">
                    @csrf
                    <input type="text" name="loginname" placeholder="name">
                    <input type="password" name="loginpassword" placeholder="password">
                    <button>Login</button>
                </form>
                <h2>Register</h2>
                <form action="/register" method="post">
                    @csrf
                    <input type="text" name="name" placeholder="name">
                    <input type="text" name="email" placeholder="email">
                    <input type="password" name="password" placeholder="password">
                    <button>Register</button>
                </form>
            @endauth
        </main>
    </div>
</body>
</html>
