<?php

use App\Models\User;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\PostController;
use App\Http\Controllers\UserController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    $posts = [];
    if (auth()->check()) {
        $posts = auth()->user()->userPosts()->latest()->get();
    }
    return view('home', ['posts' => $posts]);
});


Route::get('/newpost', function () {
    return view('postForm');
});

Route::post('/create-post', [PostController::class, 'create']);
Route::delete('/delete-post/{post}', [PostController::class, 'destroy']);

Route::get('/edit-post/{post}', [PostController::class, 'edit']);
Route::put('/edit-post/{post}', [PostController::class, 'update']);

Route::post('/register', [UserController::class, 'register'] );
Route::post('/login', [UserController::class, 'login']);
Route::post('/logout', [UserController::class, 'logout']);


