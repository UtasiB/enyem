<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Laravel Blog App</title>
    <link rel="stylesheet" href="/app.css">
</head>
<body>
    <div class="container">
        <header>
            <h1>Laravel Blog App</h1>
            <h3>Bajai SZC Türr István Technikum - 5/13.SZOFT</h3>
            <h6>2024.</h6>
        </header>
        <main>

            <?php if(auth()->guard()->check()): ?>
                <h2>Logged in</h2>
                <form action="/logout" method="post">
                    <?php echo csrf_field(); ?>
                    <a href="/newpost">Create a new post</a>
                    <button>Logout</button>
                </form>

                <h2>All posts</h2>
                <hr>
                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <h3><?php echo e($post->title); ?></h3>
                   <p><?php echo e($post->body); ?></p>
                   <a href="/edit-post/<?php echo e($post->id); ?>">Edit post</a>
                   <form action="/delete-post/<?php echo e($post->id); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button>Delete</button>
                   </form>
                   <hr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php else: ?>
                <h2>Login</h2>
                <form action="/login" method="post">
                    <?php echo csrf_field(); ?>
                    <input type="text" name="loginname" placeholder="name">
                    <input type="password" name="loginpassword" placeholder="password">
                    <button>Login</button>
                </form>
                <h2>Register</h2>
                <form action="/register" method="post">
                    <?php echo csrf_field(); ?>
                    <input type="text" name="name" placeholder="name">
                    <input type="text" name="email" placeholder="email">
                    <input type="password" name="password" placeholder="password">
                    <button>Register</button>
                </form>
            <?php endif; ?>
        </main>
    </div>
</body>
</html>
<?php /**PATH /opt/lampp/htdocs/513szoft/Laravel/blog_App/resources/views/home.blade.php ENDPATH**/ ?>