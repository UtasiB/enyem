require('dotenv').config();
const express = require('express');
var ejs = require('ejs');
const app = express();
const port = process.env.PORT;
var errorMsg = '';

app.use(express.json());
app.use(express.urlencoded({extended: true}));
app.use('/assets', express.static('assets'));

var mysql      = require('mysql');
var connection = mysql.createConnection({
  host     : process.env.DBHOST,
  user     : process.env.DBUSER,
  password : process.env.DBPASS,
  database : process.env.DBNAME
});
 
connection.connect((err)=>{
    if (err){
        console.log(err);
        return;
    }
    console.log(`Connected to MySQL database.`)
});

app.get('/', (req, res)=>{
  errorMsg = '';
  connection.query(`SELECT 
         forgalom.id as id,
         forgalom.termek as termek, 	
         forgalom.vevo as vevo, 	
         forgalom.kategoriaId as kategoriaId, 	
         forgalom.egyseg as egyseg, 	
         forgalom.mennyiseg as mennyiseg, 	
         forgalom.nettoar as nettoar, 	
         kategoria.kategoriaNev as kategoriaNev 	    
        FROM forgalom INNER JOIN kategoria ON kategoria.id = forgalom.kategoriaId`, (err, results)=>{
    if (err){
      ejs.renderFile('views/error.ejs', (err, html)=>{
        res.send(html);
      })
      return
    }
    ejs.renderFile('views/index.ejs', {results}, (err, html) => {
      if (err){
        console.log(err)
      }
      res.send(html);
    });
  });

  
})

app.get('/new', (req, res)=>{
  connection.query('SELECT * FROM kategoria ORDER BY kategoriaNev ASC', (_err, results)=>{

    ejs.renderFile('views/new.ejs', {results, errorMsg}, (err, html)=>{
      if (err){
        console.log(err)
      }
      res.send(html);
    });
  });
  
});

app.post('/new', (req, res) => {
   const { kategoriaId, termek, vevo, egyseg, nettoar, mennyiseg } = req.body;

   if (!termek || !vevo) {
      errorMsg = 'Nem adtál meg minden adatot!';
      res.redirect('/new');
      return
   }

   connection.query(`INSERT INTO forgalom (termek, vevo, kategoriaId, egyseg, nettoar, mennyiseg) VALUES('${termek}', '${vevo}', ${kategoriaId}, '${egyseg}', ${nettoar}, ${mennyiseg})`, (err, results)=>{
    
    res.redirect('/');
   });
});

app.get('/delete/:id', (req, res) => {
  let id = req.params.id;
  ejs.renderFile('views/delete.ejs', {id}, (err, html)=>{
    res.send(html);
  })
});

app.post('/delete/:id', (req, res)=>{
  let id = req.params.id;

  connection.query(`DELETE FROM forgalom WHERE id=${id}`, (err ,results)=>{
    res.redirect('/');
  });
}); 

app.listen(port, ()=>{
    console.log(`Server listening on port ${port}...`);
});