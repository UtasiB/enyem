<?php
    class Controller {

        private $model;
        private $view;

        public function __construct($model, $view)
        {
            $this->model = $model;
            $this->view = $view;
        }

        public function insert($table, $data){
            $data = $this->checkConfig($data);
            $this->view->render($this->model->create($table, $data));
        }

        public function update($table, $id, $data){
            $data = $this->checkConfig($data);
            unset($data['config']);
            $this->view->render($this->model->update($table, $id, $data));
        }

        public function select($table, $id){
            $this->view->render($this->model->read($table, $id));
        }

        public function selectAll($table){
           $this->view->render($this->model->readAll($table));
        }

        public function delete($table, $id){
            $this->view->render($this->model->delete($table, $id));
        }

        private function checkConfig($data){
            if (isset($data['config'])){
                if (isset($data['config']['required'])){
                    foreach($data['config']['required'] as $field){
                        if (!isset($data[$field])){
                            return $this->view->render("Missing data! ($field)");
                        } 
                    }
                }
                if (isset($data['config']['hashed'])){
                    foreach($data['config']['hashed'] as $field){
                        if (isset($data[$field])) {
                            $data[$field] = sha1($data[$field]);
                        }
                    }
                }
                unset($data['config']);
            }
            return $data;
        }
    }
    
    /* 
    config = [
        required = ['name', 'email', 'passwd'],
        hashed = ['passwd']    
        ]
    */
?>