<?php
   
    require_once("DotEnv.php");

    use DevCoder\DotEnv;
    (new DotEnv(__DIR__ . '/.env'))->load();

    class db {

        public $db;

        public function __construct()
        {
            $dbHost = getenv('DBHOST');
            $dbName = getenv('DBNAME');
            $dbUser = getenv('DBUSER');
            $dbPass = getenv('DBPASS');

            try{
                $this->db = new mysqli($dbHost, $dbUser, $dbPass, $dbName);
                $this->db->set_charset('utf8');
            }catch(Exception $err){
                die("Hiba az adatbázis elérése közben! (Hibakód: ".$err->getCode().")");
            }
        }
    }

?>