import { Entity, Column, PrimaryColumn } from "typeorm"

@Entity()
export class User {
    @PrimaryColumn({generated:true})
    id: number

    @Column({length: 60})
    name: string

    @Column({length: 100})
    email: string

    @Column({length: 20, nullable: true})
    phone: string

    @Column({length: 40})
    passwd: string

    @Column({length: 10})
    role: string
    
    @Column({length: 40})
    secret: string

    @Column('text')
    description: string

    @Column({default: true})
    status: boolean
}