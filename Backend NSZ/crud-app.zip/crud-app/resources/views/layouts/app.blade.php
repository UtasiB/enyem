<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Laravel CRUD app</title>
    <link rel="stylesheet" href="{{ asset('css/bootstrap.min.css') }}">
    <link rel="stylesheet" href="{{ asset('css/app.css') }}">
</head>
<body>
    <div class="container">
        <header>CARS MANAGER APP</header>
        <main>

            @if (session('message'))
                <div class="alert alert-{{ session('msgType') }}">
                    {{ session('message')}}
                </div>
            @endif

            <div class="section">
                @yield('content')
            </div>

        </main>
        <footer>Bajai SZC Türr István Technikum</footer>
    </div>
    <link rel="stylesheet" href="{{ asset('css/bootstrap.min.css') }}">

    <script src="{{ asset('js/bootstrap.min.js')}}" ></script>
</body>
</html>
