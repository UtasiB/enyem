@extends('layouts.app')

@section('content')
    <h3>Cars list</h3>

    <a href="{{ route('cars.create') }}" class="btn btn-primary">Add new car...</a>

    <br><br>

    <table class="table table-hover table-striped">
        <thead>
            <tr>
                <th>#</th>
                <th>Brand</th>
                <th>Model</th>
                <th>Color</th>
                <th class="text-end">Year</th>
                <th class="text-end">Price</th>
                <th class="text-end">Operations</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($cars as $car)

            <tr>
                <td></td>
                <td>{{ $car->brand }}</td>
                <td>{{ $car->model }}</td>
                <td>{{ $car->color }}</td>
                <td class="text-end">{{ $car->year }}</td>
                <td  class="text-end">{{ $car->price }}</td>
                <td class="text-end">
                    <a href="{{ route('cars.edit', $car) }}" class="btn btn-warning btn-sm">Edit</a>
                    <form action="{{ route('cars.destroy', $car) }}" method="POST">
                        @csrf
                        @method('DELETE')
                        <input type="submit" class="btn btn-danger btn-sm" value="Delete">
                    </form>
                </td>
            </tr>

            @endforeach
        </tbody>
        <tfoot>
            <tr>
                <td colspan="7">Summary <b>{{ sizeOf($cars) }}</b> car(s)</td>
            </tr>
        </tfoot>
    </table>

@endsection
