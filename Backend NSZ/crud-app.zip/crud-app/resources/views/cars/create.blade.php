@extends('layouts.app')

@section('content')
    <h3>Add new car</h3>

    <form action="{{ route('cars.store') }}" method="POST">

        @csrf

        <div class="form-floating mb-3">
            <input type="text" class="form-control" name="brand" placeholder="Brand name...">
            <label for="brand">Brand</label>
        </div>

        <div class="form-floating mb-3">
            <input type="text" class="form-control" name="model" placeholder="Model name...">
            <label for="model">Model</label>
        </div>

        <div class="form-floating mb-3">
            <input type="text" class="form-control" name="color" placeholder="Color...">
            <label for="color">Color</label>
        </div>

        <div class="form-floating mb-3">
            <input type="number" class="form-control" name="year" placeholder="Manufactured year..." min="1900" max="2100">
            <label for="year">Year</label>
        </div>

        <div class="form-floating mb-3">
            <input type="number" class="form-control" name="price" placeholder="Price..." min="0">
            <label for="price">Price</label>
        </div>

        <div class="form-floating mb-3">
            <textarea class="form-control" placeholder="Car short description..." name="description"></textarea>
            <label for="description">Description</label>
        </div>

        <input type="submit" value="Save CAR" class="btn btn-primary mb-3">
    </form>

    <a href="{{ route('cars.index') }}" class="btn btn-secondary">Back to list...</a>
@endsection
