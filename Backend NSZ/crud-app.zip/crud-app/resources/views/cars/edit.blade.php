@extends('layouts.app')

@section('content')
    <h3>Edit car data</h3>

    <form action="{{ route('cars.update', $car) }}" method="POST">

        @csrf
        @method('PUT')

        <div class="form-floating mb-3">
            <input type="text" class="form-control" name="brand" placeholder="Brand name..." value="{{ $car->brand }}">
            <label for="brand">Brand</label>
        </div>

        <div class="form-floating mb-3">
            <input type="text" class="form-control" name="model" placeholder="Model name..." value="{{ $car->model }}">
            <label for="model">Model</label>
        </div>

        <div class="form-floating mb-3">
            <input type="text" class="form-control" name="color" placeholder="Color..." value="{{ $car->color }}">
            <label for="color">Color</label>
        </div>

        <div class="form-floating mb-3">
            <input type="number" class="form-control" name="year" placeholder="Manufactured year..." min="1900" max="2100" value="{{ $car->year }}">
            <label for="year">Year</label>
        </div>

        <div class="form-floating mb-3">
            <input type="number" class="form-control" name="price" placeholder="Price..." min="0" value="{{ $car->price }}">
            <label for="price">Price</label>
        </div>

        <div class="form-floating mb-3">
            <textarea class="form-control" placeholder="Car short description..." name="description">{{ $car->description }}</textarea>
            <label for="description">Description</label>
        </div>

        <input type="submit" value="Update CAR" class="btn btn-warning mb-3">
    </form>

    <a href="{{ route('cars.index') }}" class="btn btn-secondary">Back to list...</a>
@endsection
