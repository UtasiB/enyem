<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Laravel CRUD app</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
</head>
<body>
    <div class="container">
        <header>CARS MANAGER APP</header>
        <main>

            <?php if(session('message')): ?>
                <div class="alert alert-<?php echo e(session('msgType')); ?>">
                    <?php echo e(session('message')); ?>

                </div>
            <?php endif; ?>

            <div class="section">
                <?php echo $__env->yieldContent('content'); ?>
            </div>

        </main>
        <footer>Bajai SZC Türr István Technikum</footer>
    </div>
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">

    <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>" ></script>
</body>
</html>
<?php /**PATH /opt/lampp/htdocs/13A/laravel/crud-app/resources/views/layouts/app.blade.php ENDPATH**/ ?>