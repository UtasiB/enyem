<?php $__env->startSection('content'); ?>
    <h3>Cars list</h3>

    <a href="<?php echo e(route('cars.create')); ?>" class="btn btn-primary">Add new car...</a>

    <br><br>

    <table class="table table-hover table-striped">
        <thead>
            <tr>
                <th>#</th>
                <th>Brand</th>
                <th>Model</th>
                <th>Color</th>
                <th class="text-end">Year</th>
                <th class="text-end">Price</th>
                <th class="text-end">Operations</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $cars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $car): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <tr>
                <td></td>
                <td><?php echo e($car->brand); ?></td>
                <td><?php echo e($car->model); ?></td>
                <td><?php echo e($car->color); ?></td>
                <td class="text-end"><?php echo e($car->year); ?></td>
                <td  class="text-end"><?php echo e($car->price); ?></td>
                <td class="text-end">
                    <a href="<?php echo e(route('cars.edit', $car)); ?>" class="btn btn-warning btn-sm">Edit</a>
                    <form action="<?php echo e(route('cars.destroy', $car)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <input type="submit" class="btn btn-danger btn-sm" value="Delete">
                    </form>
                </td>
            </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        <tfoot>
            <tr>
                <td colspan="7">Summary <b><?php echo e(sizeOf($cars)); ?></b> car(s)</td>
            </tr>
        </tfoot>
    </table>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/13A/laravel/crud-app/resources/views/cars/index.blade.php ENDPATH**/ ?>