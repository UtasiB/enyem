;

<?php $__env->startSection('content'); ?>

    <div class="container">
        <h3>Dashboard</h3>
        <hr>
        <p>Ez az oldal csak bejelentkezés után látható...</p>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/13A/laravel/companyApp/resources/views/dashboard.blade.php ENDPATH**/ ?>