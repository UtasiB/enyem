@extends('layouts.app');

@section('content')

    <div class="container">
        <h3>Dashboard</h3>
        <hr>
        <p>Ez az oldal csak bejelentkezés után látható...</p>
    </div>

@endsection
