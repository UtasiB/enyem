import { Entity, Column, PrimaryColumn, JoinColumn, ManyToOne } from "typeorm"
import { User } from "./User"
import { Product } from "./Product"

@Entity()
export class Order {
    @PrimaryColumn({generated:true})
    id: number

    @ManyToOne( () => User, (user) => user.id, { eager: true })
    @JoinColumn({name: "userId"})
    user: User

    @ManyToOne( () => Product, (product) => product.id, { eager: true })
    @JoinColumn({name: "productId"})
    product: Product

    @Column("double")
    amount: number

    @Column({type: "timestamp"})
    date: Date

    @Column({type: 'text', nullable: true})
    description: string

    @Column({default: false})
    status: boolean
}