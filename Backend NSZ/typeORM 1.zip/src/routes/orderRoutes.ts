import { Router } from "express";
import { AppDataSource } from "../data-source";
import { Order } from "../entities/Order";

const router = Router();

router.get('/', async (_req, res)=>{
    res.json(await AppDataSource.getRepository(Order).find());
});

router.get('/:id', async (req, res)=>{
    let orderId = parseInt(req.params.id);
    res.json(await AppDataSource.getRepository(Order).findOneBy({id: orderId}));
});

/**
 * Add new order
 */
router.post('/', async (req, res)=>{
    const orderRepository = AppDataSource.getRepository(Order);
    const newOrder = orderRepository.create(req.body);
    res.json(await orderRepository.save(newOrder));
});

/**
 * Update order by id
 */
router.patch('/:id', async (req, res)=>{
    let orderId = parseInt(req.params.id);
    const orderRepository = AppDataSource.getRepository(Order);
    const updatedOrder = await orderRepository.update(orderId, req.body);
    res.json(await AppDataSource.getRepository(Order).findOneBy({id: orderId}));
});

/**
 * Delete order by id
 */
router.delete('/:id', async (req, res)=>{
    let orderId = parseInt(req.params.id);
    res.json(await AppDataSource.getRepository(Order).delete(orderId));
});


export default router;