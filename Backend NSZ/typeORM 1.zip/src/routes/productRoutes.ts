import { Router } from "express";
import { AppDataSource } from "../data-source";
import { Product } from "../entities/Product";

const router = Router();

/**
 * Get All product
 */
router.get('/', async (_req, res)=>{
    res.json(await AppDataSource.getRepository(Product).find());
});

/**
 * Get one product by id
 */
router.get('/:id', async (req, res)=>{
    let productId = parseInt(req.params.id);
    res.json(await AppDataSource.getRepository(Product).findOneBy({id: productId}));
});

/**
 * Create product
 */
router.post('/', async (req, res)=>{
    const productRepository = AppDataSource.getRepository(Product);
    const newProduct = productRepository.create(req.body);
    res.json(await productRepository.save(newProduct));
});

/**
 * Update product by id
 */
router.patch('/:id', async (req, res)=>{
    let productId = parseInt(req.params.id);
    const productRepository = AppDataSource.getRepository(Product);
    const updatedProduct = await productRepository.update(productId, req.body);
    res.json(await AppDataSource.getRepository(Product).findOneBy({id: productId}));
});

/**
 * Delete product by id
 */
router.delete('/:id', async (req, res)=>{
    let productId = parseInt(req.params.id);
    res.json(await AppDataSource.getRepository(Product).delete(productId));
});

export default router;