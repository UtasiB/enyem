import { Router } from "express";
import { AppDataSource } from "../data-source";
import { User } from "../entities/User";

const router = Router();

/**
 * Get All users
 */
router.get('/', async (req, res)=>{
    /* 
    const userRepository = AppDataSource.getRepository(User);
    const users = await userRepository.find();
    res.json(users);
    */
    res.json(await AppDataSource.getRepository(User).find());
});

/**
 * Get one user by id
 */
router.get('/:id', async (req, res)=>{
    let userId = parseInt(req.params.id);
    res.json(await AppDataSource.getRepository(User).findOneBy({id: userId}));
});

/**
 * Create user
 */
router.post('/', async (req, res)=>{
    const userRepository = AppDataSource.getRepository(User);
    const newUser = userRepository.create(req.body);
    res.json(await userRepository.save(newUser));
});

/**
 * Update user by id
 */
router.patch('/:id', async (req, res)=>{
    let userId = parseInt(req.params.id);
    const userRepository = AppDataSource.getRepository(User);
    const updatedUser = await userRepository.update(userId, req.body)
    res.json(await AppDataSource.getRepository(User).findOneBy({id: userId}));
});

/**
 * Delete user by id
 */
router.delete('/:id', async (req, res)=>{
    let userId = parseInt(req.params.id);
    res.json(await AppDataSource.getRepository(User).delete(userId));
});

export default router;