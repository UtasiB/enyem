export interface Message  {
  title: string;
  message: string;
  severity: string;
}
