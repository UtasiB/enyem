export const environment = {
  production: false,
  serverUrl: `http://localhost:3000`,
  tokenName: 'szallasfoglalo'
}
