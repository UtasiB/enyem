13.a Szoftverfejelsztő
Szállásfoglaló applikáció
Database: MySQL
Frontend: Angular
Backend: NodeJS + Express
