import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { Room } from '../../interfaces/room';
import { ApiService } from '../../services/api.service';
import { RatingsComponent } from '../ratings/ratings.component';

@Component({
  selector: 'app-rooms',
  standalone: true,
  imports: [CommonModule, RatingsComponent],
  templateUrl: './rooms.component.html',
  styleUrl: './rooms.component.scss'
})

export class RoomsComponent {

  constructor(private api: ApiService){}

  rooms:Room[] = [
    {
      title: "Duna Szálló",
      address: "Baja, Szentháromság tér 1.",
      price: 4500,
      phone: "06-79/324-555",
      email: "dunaszallo@gmail.hu",
      description: "skdhfs jdgfkjds hfsa fjsahflkjsd hflkjsahfkjdsa fkjsahf kjsahfsakjdlj",
      rating: 3
    },
    {
      title: "Duna Szálló",
      address: "Baja, Szentháromság tér 1.",
      price: 4500,
      phone: "06-79/324-555",
      email: "dunaszallo@gmail.hu",
      description: "skdhfs jdgfkjds hfsa fjsahflkjsd hflkjsahfkjdsa fkjsahf kjsahfsakjdlj",
      rating: 4
    },
    {
      title: "Duna Szálló",
      address: "Baja, Szentháromság tér 1.",
      price: 4500,
      phone: "06-79/324-555",
      email: "dunaszallo@gmail.hu",
      description: "skdhfs jdgfkjds hfsa fjsahflkjsd hflkjsahfkjdsa fkjsahf kjsahfsakjdlj",
      rating: 2
    },
    {
      title: "Duna Szálló",
      address: "Baja, Szentháromság tér 1.",
      price: 4500,
      phone: "06-79/324-555",
      email: "dunaszallo@gmail.hu",
      description: "skdhfs jdgfkjds hfsa fjsahflkjsd hflkjsahfkjdsa fkjsahf kjsahfsakjdlj",
      rating: 1
    },
    {
      title: "Duna Szálló",
      address: "Baja, Szentháromság tér 1.",
      price: 4500,
      phone: "06-79/324-555",
      email: "dunaszallo@gmail.hu",
      description: "skdhfs jdgfkjds hfsa fjsahflkjsd hflkjsahfkjdsa fkjsahf kjsahfsakjdlj",
      rating: 5
    },
    {
      title: "Duna Szálló",
      address: "Baja, Szentháromság tér 1.",
      price: 4500,
      phone: "06-79/324-555",
      email: "dunaszallo@gmail.hu",
      description: "skdhfs jdgfkjds hfsa fjsahflkjsd hflkjsahfkjdsa fkjsahf kjsahfsakjdlj",
      rating: 3
    }
  ]
}
