export interface Bevasarlolista {
  tetel: string;
  egysar: number;
  mennyiseg: number;
  osszesen: number;
}
