import { Component, EventEmitter, Input, Output } from '@angular/core';
import { Bevasarlolista } from '../../interfaces/bevasarlolista';
import { CommonModule } from '@angular/common';
import { retry } from 'rxjs';

@Component({
  selector: 'app-lista',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './lista.component.html',
  styleUrl: './lista.component.scss'
})

export class ListaComponent {
  @Input() lista:Bevasarlolista[] = [];
  @Output() removeIndex = new EventEmitter<number>();

  getSummary():number{
    let sum = 0;
    this.lista.forEach(item => {
      sum+=item.osszesen;
    })
    return sum;
  }

  remove(index: number){
    this.removeIndex.emit(index);
  }
}
