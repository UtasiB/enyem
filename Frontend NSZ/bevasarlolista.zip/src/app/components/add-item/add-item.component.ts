import { Component, EventEmitter, Output } from '@angular/core';
import { Bevasarlolista } from '../../interfaces/bevasarlolista';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-add-item',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './add-item.component.html',
  styleUrl: './add-item.component.scss'
})

export class AddItemComponent {

  newItem:Bevasarlolista = {
    tetel: '',
    egysar: 0,
    mennyiseg: 0,
    osszesen: 0
  };

  @Output() addItem = new EventEmitter<Bevasarlolista>();

  addNewItem(){
    this.newItem.osszesen = this.newItem.mennyiseg * this.newItem.egysar;
    this.addItem.emit(this.newItem);
    this.newItem = {
      tetel: '',
      egysar: 0,
      mennyiseg: 0,
      osszesen: 0
    };
  }
}
