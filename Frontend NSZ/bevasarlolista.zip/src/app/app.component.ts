import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HeaderComponent } from './components/header/header.component';
import { FooterComponent } from './components/footer/footer.component';
import { ListaComponent } from './components/lista/lista.component';
import { Bevasarlolista } from './interfaces/bevasarlolista';
import { AddItemComponent } from "./components/add-item/add-item.component";

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, HeaderComponent, FooterComponent, ListaComponent, AddItemComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.scss'
})

export class AppComponent implements OnInit{

  title = 'Bevásárlólista Applikácó';
  company = "Bajai SZC Türr István Technikum";
  author = '13.a szoftverfejelsztő';

  bevasarlolista:Bevasarlolista[] = [];

  ngOnInit(): void {
    let lista = localStorage.getItem('bevlista');
    this.bevasarlolista = (lista) ? JSON.parse(lista) : [];
  }

  addItemToList(item:Bevasarlolista){
    this.bevasarlolista.push(item);
    this.saveList();
  }

  deleteFromList(index:number){
    this.bevasarlolista.splice(index, 1);
    this.saveList();
  }

  saveList(){
    localStorage.setItem('bevlista', JSON.stringify(this.bevasarlolista));
  }
}
