<?php
    
    require_once("config/database.php");
    require_once("model/model.php");
    require_once("controller/controller.php");
    require_once("view/view.php");


    $db = new db();
    $model = new Model($db);
    $view= new View();
    $controller = new Controller($model, $view);

    switch($_SERVER['REQUEST_METHOD']){

        case 'GET': { 
            if (isset($_GET['table']) && isset($_GET['id'])){
                $table = $_GET['table'];
                $id =$_GET['id'];
                $controller->select($table, $id);
                break;
            }
            if (isset($_GET['table'])){
                $table = $_GET['table'];
                $controller->selectAll($table);
                break;
            }
            break;
        }
        
        case 'POST': { 
            if (isset($_GET['login'])){
                $table = $_GET['table'];
                $input = file_get_contents('php://input');
                parse_str($input, $data);
                $controller->login($table, $data);
            }
            if (isset($_GET['table']) && !isset($_GET['login'])){
                $table = $_GET['table'];
                $input = file_get_contents('php://input');
                parse_str($input, $data);
                $controller->insert($table, $data);
                break;
            }          
            break;
        }

        case 'PATCH': { 
            if (isset($_GET['table']) && isset($_GET['id'])){
                $table = $_GET['table'];
                $id =$_GET['id'];
                $input = file_get_contents('php://input');
                parse_str($input, $data);
                $controller->update($table, $id, $data);
                break;
            }        
            break;
        }

        case 'DELETE': { 
            if (isset($_GET['table']) && isset($_GET['id'])){
                $table = $_GET['table'];
                $id =$_GET['id'];
                $controller->delete($table, $id);
                break;
            } 
            break;
        }
    }
    
?>