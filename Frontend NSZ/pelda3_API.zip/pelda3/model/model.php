<?php
    class Model {

        private $db;

        public function __construct($db)
        {
            $this->db = $db->db;    
        }

        public function create($table, $data){
            $fields = array_keys($data);
            $values = array_values($data);
            $values = array_map(function($value) {
                return "'" . $value . "'";
            }, $values);
            $id = $this->uuidv4();
            $this->db->query("INSERT INTO $table (ID, ".implode(',', $fields).") VALUES('$id',".implode(',', $values).")");
            return $id;
        }

        public function readAll($table){
            return $this->db->query("SELECT * FROM $table")->fetch_all();
        }

        public function read($table, $id){
            return $this->db->query("SELECT * FROM $table WHERE ID='$id'")->fetch_all();
        }
    
        public function update($table, $id, $data){
            $fields = array_keys($data);
            $values = array_values($data);
            $paired = array_map(function($field, $value) {
                return "$field='$value'";
            }, $fields, $values);

            $this->db->query("UPDATE $table SET ".implode(',', $paired)." WHERE ID='$id'");
            return $this->db->affected_rows;

        }

        public function delete($table, $id){
          $this->db->query("DELETE FROM $table WHERE ID='$id'");
          return $this->db->affected_rows;
        }

        public function login($table, $data){
            return $this->db->query("SELECT * FROM $table WHERE email='".$data['email']."' AND passwd='".$data['passwd']."'")->fetch_all();
        }

        private function uuidv4()
        {
            $data = random_bytes(16);
            $data[6] = chr(ord($data[6]) & 0x0f | 0x40); // set version to 0100
            $data[8] = chr(ord($data[8]) & 0x3f | 0x80); // set bits 6-7 to 10
            return vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex($data), 4));
        }
    }
?>