<?php
    class View {
       
        public function __construct()
        {
        }

        public function render($data){
            header('Content-Type: application/JSON; charset=utf-8;');
            echo json_encode($data);
        }
    }
?>