export interface torpe {
  id: number;
  nev: string;
  klan: string;
  nem: string;
  suly: number;
  magassag: number;
}
