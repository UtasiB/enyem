import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})

export class ApiService {

  constructor(private http: HttpClient) { }

 // serverURL = 'http://localhost:3001';
  serverURL = 'https://torpekapi.sugo-media.hu';

  select(){
    return this.http.get(this.serverURL + '/torpek');
  }
}
