import { Routes } from '@angular/router';
import { TorpekComponent } from './torpek/torpek.component';

export const routes: Routes = [
  {
    path: '', component: TorpekComponent
  }
];
