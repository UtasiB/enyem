import { AfterViewInit, Component, OnInit, ViewChild } from '@angular/core';
import { ApiService } from '../api.service';
import {MatSnackBar, MatSnackBarModule} from '@angular/material/snack-bar';
import {MatTableDataSource, MatTableModule} from '@angular/material/table';
import {MatPaginator, MatPaginatorModule} from '@angular/material/paginator';
import {MatSort, MatSortModule} from '@angular/material/sort';
import { torpe } from '../torpe';

@Component({
  selector: 'app-torpek',
  standalone: true,
  imports: [MatSnackBarModule, MatTableModule, MatPaginatorModule, MatSortModule],
  templateUrl: './torpek.component.html',
  styleUrl: './torpek.component.scss'
})

export class TorpekComponent implements OnInit, AfterViewInit{

  constructor(
    private api:ApiService,
    private snackBar: MatSnackBar
  ){}

  displayedColumns: string[] = ['id', 'nev', 'klan', 'nem', 'suly', 'magassag'];
  dataSource = new MatTableDataSource<torpe>();

  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;

  ngOnInit(): void {
      this.api.select().subscribe({
        next: (res) => {
          this.dataSource.data = res as torpe[];
          this.snackBar.open('Adatok betöltve', 'OK');
        },
        error: (err) => {
          this.snackBar.open(err, 'OK');
        }
      })
  }

  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

}
