import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HeaderComponent } from "./components/header/header.component";
import { FooterComponent } from "./components/footer/footer.component";
import { UsersComponent } from "./components/users/users.component";
import { SelectedUsersComponent } from "./components/selected-users/selected-users.component";
import { User } from './interfaces/users';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, HeaderComponent, FooterComponent, UsersComponent, SelectedUsersComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.scss'
})

export class AppComponent implements OnInit {
  title = 'Komponensek Példa';
  company = 'Bajai SZC Türr István Technikum';
  author = '13.a szoftverfejelesztő';

  selUsers:User[] = [];

  users:User[] = [
    {
      name: 'Béla',
      email: 'bela@gmail.com',
      selected: false
    },
    {
      name: 'Józsi',
      email: 'jozsi@gmail.com',
      selected: false
    },
    {
      name: 'Károly',
      email: 'karcsi@gmail.com',
      selected: true
    },
    {
      name: 'Éva',
      email: 'eva@gmail.com',
      selected: false
    },
    {
      name: 'Géza',
      email: 'geza@gmail.com',
      selected: false
    },
  ];

  ngOnInit(): void {
    const selected = this.users.filter(user => user.selected);
    this.updateSelectedUsersList(selected)
  }

  updateSelectedUsersList($event: User[]){
    this.selUsers = $event;
  }
}
