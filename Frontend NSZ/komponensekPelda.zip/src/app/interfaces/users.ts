export interface User {
  name: string;
  address?: string;
  email: string;
  phone?: string;
  age?: number;
  gender?: string;
  selected: boolean;
}
