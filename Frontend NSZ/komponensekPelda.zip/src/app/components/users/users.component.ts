import { Component, EventEmitter, Input, Output } from '@angular/core';
import { User } from '../../interfaces/users';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-users',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './users.component.html',
  styleUrl: './users.component.scss'
})

export class UsersComponent {
  @Input() users:User[] = [];
  @Output() selectedUsers = new EventEmitter<User[]>();

  emitSelectedUsers(){
    const selected = this.users.filter(user => user.selected);
    this.selectedUsers.emit(selected);
  }

  toggleSelection(user:User){
    user.selected = ! user.selected;
    this.emitSelectedUsers();
  }
}
