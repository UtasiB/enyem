let stepdatas = [];
let chart = null;

function addStep(){
    let data = {
        date: document.querySelector('#date').value,
        stepcount: document.querySelector('#steps').value
    }

    axios.post(`${serverUrl}/steps/${loggedUser[0].ID}`, data, authorize()).then(res =>{
        alert(res.data);

        if (res.status == 200){
            document.querySelector('#date').value = null;
            document.querySelector('#steps').value = null;
            getStepDatas();
        }
    });
}

function updateStep(){
    let data = {
        date: document.querySelector('#date').value,
        stepcount: document.querySelector('#steps').value
    }

    axios.patch(`${serverUrl}/steps/${loggedUser[0].ID}`, data, authorize()).then(res =>{
        alert(res.data);

        if (res.status == 200){
            cancel();
            getStepDatas();
        }
    });
}

function deleteStep(){
    if (confirm('Are you shure to delete then selected data?')){
        let date = document.querySelector('#date').value;
    
        axios.delete(`${serverUrl}/steps/${loggedUser[0].ID}/${date}`, authorize()).then(res =>{
            alert(res.data);

            if (res.status == 200){
                cancel();
                getStepDatas();
            }
        });
    }
}

function deleteAllSteps(){
    if (confirm('Are you shure to delete all data?')){
        axios.delete(`${serverUrl}/steps/${loggedUser[0].ID}`, authorize()).then(res =>{
            alert(res.data);

            if (res.status == 200){
                cancel();
                getStepDatas();
            }
        });
    }
}

function cancel(){
    document.querySelector('.insertmode').classList.remove('d-none');
    document.querySelectorAll('.editmode').forEach(item =>{
        item.classList.add('d-none');
    });
    document.querySelector('#date').value = null;
    document.querySelector('#steps').value = null;
}

function renderTable(){
    let tbody = document.querySelector('tbody');
    tbody.innerHTML = '';

    let summary = 0;
    stepdatas.forEach((item, index) =>{
        let tr = document.createElement('tr');

        tr.onclick = function() {selectRow(Number(index))};
        
        let td1 = document.createElement('td');
        let td2 = document.createElement('td');
        let td3 = document.createElement('td');

        td1.innerHTML = (index +1) + '.';
        td2.innerHTML = moment(item.date).format('YYYY-MM-DD');
        td3.innerHTML = item.count;
        td3.classList.add('text-end');
        tr.appendChild(td1);
        tr.appendChild(td2);
        tr.appendChild(td3);
        tbody.appendChild(tr);
        summary += item.count;
    });
    document.querySelector('strong').innerHTML = summary;
}

function renderCalendar(){
        let userEvents = [];

        stepdatas.forEach(item =>{
            userEvents.push({title: `Steps: ${item.count}`, start: item.date, allDay : true,})
        });

        setTimeout(()=>{
            var calendarEl = document.getElementById('calendar');
    
            var calendar = new FullCalendar.Calendar(calendarEl, {
              initialDate: moment(new Date).format('YYYY-MM-DD'),
              editable: false,
              selectable: false,
              businessHours: false,
              dayMaxEvents: false, // allow "more" link when too many events
              events: userEvents
            });
        
            calendar.render();
        }, 1000);
       
}

function renderChart(){

    stepdatas.sort((a, b) => a.date.localeCompare(b.date));
 
    const ctx = document.getElementById('chart');

    let userdataLabels = [];
    let userdata = [];

    stepdatas.forEach(item =>{
        userdataLabels.push(moment(item.date).format('YYYY-MM-DD'));
        userdata.push(item.count);
    });

    if (chart) {
        chart.destroy();
    }

    chart = new Chart(ctx, {
      type: 'line',
      data: {
        labels: userdataLabels,
        datasets: [{
          label: 'Count of steps',
          data: userdata,
          borderWidth: 3
        }]
      },
      options: {
        scales: {
          y: {
            beginAtZero: true
          }
        }
      }
    });
}

function getStepDatas(){
    axios.get(`${serverUrl}/steps/${loggedUser[0].ID}`, authorize()).then(res => {
        stepdatas = res.data;
        // rendezzük a kapott adatokat dátum szerint csökkenőbe
        stepdatas.sort((a, b) => b.date.localeCompare(a.date));
        renderTable();
        renderCalendar();
        // rendezzük a kapott adatokat dátum szerint növekvőbe
        stepdatas.sort((a, b) => a.date.localeCompare(b.date));
        renderChart();
    });
}

function selectRow(index){
    document.querySelector('.insertmode').classList.add('d-none');
    document.querySelectorAll('.editmode').forEach(item =>{
        item.classList.remove('d-none');
    });

    document.querySelector('#date').value = moment(stepdatas[index].date).format('YYYY-MM-DD');
    document.querySelector('#steps').value = stepdatas[index].count;
}

function getAdminStats(){
    let alldata = [];
    axios.get(`${serverUrl}/steps`, authorize()).then(res => {
        
        alldata = res.data;
    
        alldata.sort((a, b) => a.userID.localeCompare(b.userID)); 

        let totalValue = 0;
        let userCount = 0;

        let userTotal = 0;
        let userDataCount = 0;
        
        let userAvg = [];
        let avgValue = 0;
        let minValue = Number.MAX_VALUE;
        let maxValue = 0;
        let userID = alldata[0].userID;

        alldata.forEach(item => {

            if (userID != item.userID){
                userAvg.push(Math.round(userTotal / userDataCount));
                console.log(userTotal)
                userID = item.userID;
                userTotal = 0;
                userDataCount = 0;
                userCount++;
            }

            totalValue += item.count;

            userTotal += item.count;
            userDataCount++;

            if (item.count > maxValue){
                maxValue = item.count;
            }
            if (item.count < minValue){
                minValue = item.count;
            }
            
        });

        userAvg.push(Math.round(userTotal / userDataCount));
        userCount++;

        let sumAvg = 0;
        userAvg.forEach(item =>{
            sumAvg += item;
        });

        avgValue = Math.round(sumAvg / userCount);

        document.querySelector('#adm_total').innerHTML = totalValue;
        document.querySelector('#adm_avg').innerHTML = avgValue;
        document.querySelector('#adm_min').innerHTML = minValue;
        document.querySelector('#adm_max').innerHTML = maxValue;
    });
}

function getUserStats(){
    axios.get(`${serverUrl}/steps/${loggedUser[0].ID}`, authorize()).then(res => {
        stepdatas = res.data;
    });

    let totalValue = 0;
    let avgValue = 0;
    let minValue = Number.MAX_VALUE;
    let maxValue = 0;

    stepdatas.forEach(item => {
        totalValue += item.count;
        if (item.count > maxValue){
            maxValue = item.count;
        }
        if (item.count < minValue){
            minValue = item.count;
        }
    });

    avgValue = Math.round(totalValue / stepdatas.length);

    document.querySelector('#total').innerHTML = totalValue;
    document.querySelector('#avg').innerHTML = avgValue;
    document.querySelector('#min').innerHTML = minValue;
    document.querySelector('#max').innerHTML = maxValue;
}