<?php

namespace App\Http\Controllers;

use App\Models\Post;
use Illuminate\Http\Request;

class PostController extends Controller
{
    /**
     * összes post lekérdezése (felhasználói adatokkal együtt)
     */
    public function index()
    {
        $posts = Post::with('user')->get();
        return response()->json($posts, 200);
    }

    /**
     * Új poszt felvétele
     */
    public function store(Request $request)
    {
        $request->validate([
            'title' => 'required|string|max:255',
            'body' => 'string'
        ]);

        $post = Post::create($request->all());

        return response()->json($post, 201);
    }

    /**
     * egy adott post lekérdezése (felhasználói adatokkal)
     */
    public function show(Post $post)
    {
        $post->load('user', 'comments');
        return response()->json($post, 200);
    }

    /**
     * Poszt módosítása
     */
    public function update(Request $request, Post $post)
    {
      /*  if ($request->user()->id != $post->user_id){
            return response()->json(['message' => 'Nincs jogosultságod!'], 403);
        }*/

        $request->validate([
            'title' => 'required|string|max:255',
            'body' => 'string'
        ]);

        $post->update($request->all());

        return response()->json($post, 200);
    }

    /**
     * Poszt törlése
     */
    public function destroy(Request $request, Post $post)
    {
     /*   if ($request->user()->id != $post->user_id){
            return response()->json(['message' => 'Nincs jogosultságod!'], 403);
        }*/

        $post->delete();

        return response()->json(['message' => 'Poszt törölve!'], 200);
    }

}
