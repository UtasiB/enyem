export interface User {
  id: string;
  name: string;
  email: string;
  passwd: string;
  confirm: string;
  role: string;
}
