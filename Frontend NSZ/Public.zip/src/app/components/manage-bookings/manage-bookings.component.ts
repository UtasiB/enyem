import { Component } from '@angular/core';

@Component({
  selector: 'app-manage-bookings',
  standalone: true,
  imports: [],
  templateUrl: './manage-bookings.component.html',
  styleUrl: './manage-bookings.component.scss'
})
export class ManageBookingsComponent {

}
