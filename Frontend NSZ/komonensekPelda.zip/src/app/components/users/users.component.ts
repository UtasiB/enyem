import { Component, EventEmitter, Input, Output } from '@angular/core';
import { User } from '../../interfaces/users';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-users',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './users.component.html',
  styleUrl: './users.component.scss'
})

export class UsersComponent {
  @Input() users:User[] = [];
  @Output() selectedUsers = new EventEmitter<User[]>();
  allCheck: boolean = false;
  emitSelectedUsers(){
    const selected = this.users.filter(user => user.selected);
    this.selectedUsers.emit(selected);
  }

  toggleSelection(user:User){
    user.selected = ! user.selected;
    this.emitSelectedUsers();
  }

  toggleAllSelection(){
    this.users.forEach(user =>{
      user.selected = this.allCheck;
    });
    this.emitSelectedUsers();
  }
}
