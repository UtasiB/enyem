import { Component, Input } from '@angular/core';
import { User } from '../../interfaces/users';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-selected-users',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './selected-users.component.html',
  styleUrl: './selected-users.component.scss'
})
export class SelectedUsersComponent {
  @Input() users:User[] = [];
}
