<div class="py-3">
    <h3>Login</h3>
    <hr>

    <?php
        if (isset($_POST['login'])){
          
            $email = escapeshellcmd($_POST['email']);
            $passwd = escapeshellcmd($_POST['passwd']);
          
            // if empty
            // if valid
        
            $data = 'name='.$name.'&email='.$email.'&passwd='.sha1($passwd);

            $result = sendRequest('POST', '?table=users&login', $data);
            
            if (sizeOf($result) != 0){
                $_SESSION['uid'] = $result[0][0];
                header('location: index.php');
            }
            
        }
    ?>

    <form action="?pg=login" method="post">

        <div class="form-floating mb-3">
            <input type="email" class="form-control" name="email" placeholder="">
            <label for="email">E-mail</label>
        </div>

        <div class="form-floating mb-3">
            <input type="password" class="form-control"  name="passwd"  placeholder="">
            <label for="passwd">Password</label>
        </div>

        <input type="submit" value="Login" name="login" class="btn btn-primary">
    </form>

</div>