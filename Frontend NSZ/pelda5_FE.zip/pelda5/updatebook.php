<?php logincheck(); ?>
<div class="py-3">
    <h3>Update book</h3>
    <hr>

    <?php
            $id = $_GET['id'];

            if (isset($_POST['update'])){

                $title = escapeshellcmd($_POST['title']);
                $author = escapeshellcmd($_POST['author']);
                $cat = escapeshellcmd($_POST['cat']);
                $price = escapeshellcmd($_POST['price']);
                $year = escapeshellcmd($_POST['year']);

                // ellenőrzések

                $data = 'title='.$title.'&author='.$author.'&category='.$cat.'&price='.$price.'&published_year='.$year;

                $result = sendRequest('PATCH', '?table=books&id='.$id, $data);

                // if ....

                header('location: index.php');

            }else{
                $result = sendRequest('GET', '?table=books&id='.$id);
                $book = $result[0];
            }
    ?>
    
    <form action="?pg=update&id=<?php echo $id; ?>" method="post">

        <div class="form-floating mb-3">
            <input type="text" class="form-control" name="title" placeholder="" value="<?php echo $book[1]; ?>">
            <label for="title">Title</label>
        </div>

        <div class="form-floating mb-3">
            <input type="text" class="form-control" name="author" placeholder="" value="<?php echo $book[2]; ?>">
            <label for="author">Author</label>
        </div>

        <div class="form-floating mb-3">
            <input type="text" class="form-control"  name="cat"  placeholder="" value="<?php echo $book[3]; ?>">
            <label for="cat">Category</label>
        </div>

        <div class="form-floating mb-3">
            <input type="number" class="form-control"  name="price"  placeholder="" value="<?php echo $book[4]; ?>">
            <label for="price">Price</label>
        </div>

        <div class="form-floating mb-3">
            <input type="number" class="form-control"  name="year"  placeholder="" value="<?php echo $book[5]; ?>">
            <label for="year">Published year</label>
        </div>

        <input type="submit" value="Update" name="update" class="btn btn-warning">
    </form>

</div>