<div class="py-3">
    <h3>Booklist</h3>
    <hr>
    <?php
        if (isset($_SESSION['uid'])){
            echo '<a href="?pg=new" class="btn btn-primary mb-3">Add new book...</a>';
        }
    ?>
   

    <table class="table table-striped table-hover">
        <thead>
            <tr>
                <th>#</th>
                <th>Title</th>
                <th>Author</th>
                <th>Category</th>
                <th class="text-end nowrap">Price</th>
                <th class="text-end">Published</th>
                <?php 
                     if (isset($_SESSION['uid'])){
                        echo '<th class="text-end">Operations</th>';
                     }
                ?>
            </tr>
        </thead>
        <tbody>

        <?php

            $results = sendRequest('GET', '?table=books');

            if ($results){
                $i = 1;
                foreach($results as $result){
                    echo '<tr>
                    <td>'.$i.'.</td>
                    <td>'.$result[1].'</td>
                    <td>'.$result[2].'</td>
                    <td>'.$result[3].'</td>
                    <td class="text-end nowrap">'.number_format($result[4], 0, '.', '.').' Ft</td>
                    <td class="text-end">'.$result[5].'</td>';
                    
                    if (isset($_SESSION['uid'])){
                        echo '<td class="nowrap">
                        <a href="?pg=update&id='.$result[0].'" class="btn btn-warning btn-sm">Update</a>
                        <a href="?pg=delete&id='.$result[0].'" class="btn btn-danger btn-sm">Delete</a>
                        </td>';
                    }
                    echo '</tr>';
                    $i++;
                }
            }
        ?>

        </tbody>
        <tfoot>
            <tr>
                <td colspan="7" class="text-center"><?php echo sizeOf($results); ?> book(s)</td>
            </tr>
        </tfoot>
    </table>


</div>