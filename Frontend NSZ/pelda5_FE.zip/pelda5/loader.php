<?php
    $pg = @$_GET['pg'];

    switch($pg){
        case 'new': {
            include('newbook.php');
            break;
        }
        case 'update': {
            include('updatebook.php');
            break;
        }
        case 'delete': {
            include('deletebook.php');
            break;
        }
        case 'login': {
            include('login.php');
            break;
        }
        case 'logout': {
            unset($_SESSION['uid']);
            header('location: index.php');
            break;}
        case 'register': {
            include('registration.php');
            break;
        }
        default: { include('booklist.php');}
    }
?>