<?php logincheck(); ?>
<div class="py-3">
    <h3>Delete book</h3>
    <hr>

    <?php logincheck(); ?>
<div class="py-3">
    <h3>Update book</h3>
    <hr>
    Are you sure to delete this book? <br>
    <?php
            $id = $_GET['id'];

            if (isset($_POST['delete'])){

                // ellenőrzések

                $result = sendRequest('DELETE', '?table=books&id='.$id);

                // if ....

                header('location: index.php');

            }else{
                $result = sendRequest('GET', '?table=books&id='.$id);
                $book = $result[0];
            }
    ?>
    
    <form action="?pg=delete&id=<?php echo $id; ?>" method="post">

        <div class="form-floating mb-3">
            <input type="text" class="form-control" name="title" placeholder="" value="<?php echo $book[1]; ?>" disabled>
            <label for="title">Title</label>
        </div>

        <div class="form-floating mb-3">
            <input type="text" class="form-control" name="author" placeholder="" value="<?php echo $book[2]; ?>" disabled>
            <label for="author">Author</label>
        </div>

        <div class="form-floating mb-3">
            <input type="text" class="form-control"  name="cat"  placeholder="" value="<?php echo $book[3]; ?>" disabled>
            <label for="cat">Category</label>
        </div>

        <div class="form-floating mb-3">
            <input type="number" class="form-control"  name="price"  placeholder="" value="<?php echo $book[4]; ?>" disabled>
            <label for="price">Price</label>
        </div>

        <div class="form-floating mb-3">
            <input type="number" class="form-control"  name="year"  placeholder="" value="<?php echo $book[5]; ?>" disabled>
            <label for="year">Published year</label>
        </div>

        <input type="submit" value="Delete" name="delete" class="btn btn-danger">
    </form>

</div>

</div>