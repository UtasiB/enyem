<div class="py-3">
    <h3>Registration</h3>
    <hr>

    <?php
        if (isset($_POST['reg'])){
            $name = escapeshellcmd($_POST['name']);
            $email = escapeshellcmd($_POST['email']);
            $passwd = escapeshellcmd($_POST['passwd']);
            $confirm = escapeshellcmd($_POST['confirm']);

            // if empty
            // if passwd
            // if email

            $data = 'name='.$name.'&email='.$email.'&passwd='.sha1($passwd);

            $result = sendRequest('POST', '?table=users', $data);
            
            // if result
            
            header('location: index.php?pg=login');
        }
    ?>

    <form action="?pg=register" method="post">

        <div class="form-floating mb-3">
            <input type="text" class="form-control" name="name" placeholder="">
            <label for="name">Name</label>
        </div>

        <div class="form-floating mb-3">
            <input type="email" class="form-control" name="email" placeholder="">
            <label for="email">E-mail</label>
        </div>

        <div class="form-floating mb-3">
            <input type="password" class="form-control"  name="passwd"  placeholder="">
            <label for="passwd">Password</label>
        </div>

        <div class="form-floating mb-3">
            <input type="password" class="form-control"  name="confirm"  placeholder="">
            <label for="confirm">Password confirm</label>
        </div>

        <input type="submit" value="Register" name="reg" class="btn btn-primary">
    </form>

</div>