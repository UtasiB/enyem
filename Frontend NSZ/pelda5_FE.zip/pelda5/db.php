<?php

    $API_URL = 'http://localhost/13A/PHP/pelda3/index.php';
    

    function sendRequest($method, $url, $data = null){

        $s = curl_init();
    
        curl_setopt($s, CURLOPT_URL, $GLOBALS
        ['API_URL'].$url);
        curl_setopt($s, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($s, CURLOPT_HTTPHEADER, array('Content-Type: application/x-www-form-urlencoded'));

        switch($method){
            case 'GET': {    
                break;
            }
            case 'POST': {
                curl_setopt($s, CURLOPT_POST, true);
                if ($data){
                    curl_setopt($s, CURLOPT_POSTFIELDS, $data);                
                }
                break;
            }
            case 'PATCH': {
                curl_setopt($s, CURLOPT_CUSTOMREQUEST, $method);
                if ($data){
                    curl_setopt($s, CURLOPT_POSTFIELDS, $data);                
                }
                break;
            }
            case 'DELETE': {
                curl_setopt($s, CURLOPT_CUSTOMREQUEST, $method);
                break;
            }
        }
    
        $results = curl_exec($s);
        curl_close($s);
        $results = json_decode($results, true);
        return $results;
    }

    function logincheck(){
        if (!isset($_SESSION['uid'])){
            header('location:index.php');
        }
    }
?>